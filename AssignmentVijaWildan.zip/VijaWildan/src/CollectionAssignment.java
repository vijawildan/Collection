import java.util.*;

/**
 *
 * @author OWNER
 */
public class CollectionAssignment{

    public static void main(String[] args) {
        
        System.out.println("List:");
        System.out.println("\n\n");

        List<String> List = new ArrayList<>();
 
        List.add("A");
        List.add("B");
        List.add("C");
        List.add("D");
 
        System.out.println("List :");
        for (String fruit : List)
        {
            System.out.println(fruit);
        }
        System.out.println("");
        
        Set<String> Set = new HashSet<String>();
        Set.add("A");
        Set.add("B");
        Set.add("C");
        Set.add("D");
        
        System.out.println("Set :");
        System.out.println(Set);
        System.out.println("");
        
        Map<Integer, String> map = new HashMap<Integer, String>();

        map.put(1, "A");
        map.put(2, "B");
        map.put(3, "C");
        map.put(4, "D");
 
        System.out.println("Map :");
        for (Map.Entry m : map.entrySet())
        {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        System.out.println("");

        LinkedList<String> linkedListStack = new LinkedList<String>();
        linkedListStack.add("A");
        linkedListStack.add("B");
        linkedListStack.add("C");
        linkedListStack.add("D");
        
        System.out.println("LinkedList (Stack)");
        System.out.println(linkedListStack);
        System.out.println("After pop");
        linkedListStack.removeLast();
        System.out.println(linkedListStack);
        System.out.println("\n");

        LinkedList<String> linkedListQueue = new LinkedList<String>();
        linkedListStack.add("A");
        linkedListStack.add("B");
        linkedListStack.add("C");
        linkedListStack.add("D");
        
        System.out.println("LinkedList (Queue)");
        System.out.println(linkedListStack);
        System.out.println("after dequeue:");
        linkedListStack.remove();
        System.out.println(linkedListStack);
    }
}